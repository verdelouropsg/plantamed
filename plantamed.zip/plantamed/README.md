# 🌿 PlantaMed — Diagnóstico de Plantas com IA

Aplicativo que analisa fotos de plantas e identifica problemas como pragas, deficiência hídrica, doenças fúngicas e mais — usando a API da Anthropic (Claude).

---

## 📁 Estrutura do projeto

```
plantamed/
├── server.js          ← Backend Node.js (guarda sua chave de API)
├── package.json
├── .env.example       ← Modelo do arquivo de configuração
├── .gitignore
└── public/
    └── index.html     ← Frontend (seu site)
```

---

## 🚀 Como rodar localmente

### 1. Instale as dependências
```bash
npm install
```

### 2. Configure sua chave de API
```bash
cp .env.example .env
```
Abra o arquivo `.env` e coloque sua chave:
```
ANTHROPIC_API_KEY=sk-ant-api03-SUA_CHAVE_AQUI
```
> Obtenha sua chave em: https://console.anthropic.com/settings/keys

### 3. Inicie o servidor
```bash
npm start
```

### 4. Acesse no navegador
```
http://localhost:3000
```

---

## ☁️ Deploy no Railway (grátis)

1. Crie conta em https://railway.app
2. Clique em **"New Project" → "Deploy from GitHub"**
3. Suba este projeto no GitHub e conecte
4. No painel do Railway, vá em **Variables** e adicione:
   ```
   ANTHROPIC_API_KEY = sk-ant-api03-SUA_CHAVE_AQUI
   ```
5. Railway detecta automaticamente o `package.json` e faz o deploy

Seu app ficará em: `https://plantamed-xxxx.up.railway.app`

---

## ☁️ Deploy no Vercel

1. Instale o CLI: `npm i -g vercel`
2. Rode: `vercel`
3. Adicione a variável de ambiente no painel do Vercel:
   - `ANTHROPIC_API_KEY` = sua chave

> ⚠️ O Vercel usa **Serverless Functions** — para funcionar, mova o conteúdo de `server.js` para `api/diagnose.js` no formato de função serverless. Me peça e gero essa versão.

---

## 🌐 Colocar no seu site existente

Se você já tem um site com servidor Node.js/Express:

1. Copie o conteúdo de `server.js` para o seu servidor
2. Adicione a rota `POST /api/diagnose`
3. Sirva o `public/index.html` ou integre o HTML ao seu template
4. Configure `ANTHROPIC_API_KEY` nas variáveis de ambiente do seu servidor

---

## 🔧 Personalização

No `public/index.html`, linha:
```js
const API_URL = "/api/diagnose";
```
Se o frontend e o backend estiverem em domínios diferentes, troque para a URL completa:
```js
const API_URL = "https://meu-backend.railway.app/api/diagnose";
```
E no `server.js`, ajuste o CORS:
```js
app.use(cors({ origin: "https://meusite.com.br" }));
```

---

## 🔒 Segurança

- ✅ A chave de API **nunca aparece** no frontend
- ✅ O backend valida o tipo e tamanho da imagem
- ✅ Fácil adicionar rate limiting com `express-rate-limit`

---

## 📦 Dependências

- `express` — servidor web
- `cors` — permite requisições do frontend
- Node.js 18+ (built-in `fetch`)
